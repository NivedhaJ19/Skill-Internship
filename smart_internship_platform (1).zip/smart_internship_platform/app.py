from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Demo data for the prototype. Replace/extend this with a database in a larger project.
ROLE_SKILLS = {
    "Full-Stack Developer": {
        "JavaScript": 5, "HTML & CSS": 4, "React": 4, "SQL": 3,
        "Backend APIs": 4, "Git & GitHub": 3
    },
    "Data Analyst": {
        "Excel": 4, "SQL": 4, "Python": 4, "Statistics": 3,
        "Data Visualization": 4, "Pandas": 3
    },
    "AI/ML Engineer": {
        "Python": 5, "Statistics": 4, "Machine Learning": 4,
        "SQL": 3, "Data Structures": 3, "Pandas": 3
    },
    "Cybersecurity Analyst": {
        "Networking": 4, "Linux": 3, "Python": 3,
        "Security Fundamentals": 5, "Log Analysis": 3
    },
    "UI/UX Designer": {
        "Figma": 4, "Wireframing": 4, "Prototyping": 4,
        "User Research": 3, "Visual Design": 4
    }
}

INTERNSHIPS = [
    {
        "title": "Junior Web Developer Intern",
        "company": "DemoTech",
        "role": "Full-Stack Developer",
        "skills": ["HTML & CSS", "JavaScript", "Git & GitHub"],
        "mode": "Hybrid",
        "stipend": "Stipend details to be verified",
        "level": "Beginner-friendly",
        "url": "https://example.com"
    },
    {
        "title": "Frontend Developer Intern",
        "company": "WebWorks (Sample Listing)",
        "role": "Full-Stack Developer",
        "skills": ["HTML & CSS", "JavaScript", "React"],
        "mode": "Remote",
        "stipend": "Not specified",
        "level": "Beginner / Intermediate",
        "url": "https://example.com"
    },
    {
        "title": "Data Analyst Intern",
        "company": "InsightLab (Sample Listing)",
        "role": "Data Analyst",
        "skills": ["Excel", "SQL", "Python", "Data Visualization"],
        "mode": "Remote",
        "stipend": "Not specified",
        "level": "Beginner-friendly",
        "url": "https://example.com"
    },
    {
        "title": "Machine Learning Intern",
        "company": "ModelWorks (Sample Listing)",
        "role": "AI/ML Engineer",
        "skills": ["Python", "Statistics", "Machine Learning", "Pandas"],
        "mode": "Hybrid",
        "stipend": "Not specified",
        "level": "Intermediate",
        "url": "https://example.com"
    },
    {
        "title": "Security Operations Intern",
        "company": "SecureStart (Sample Listing)",
        "role": "Cybersecurity Analyst",
        "skills": ["Networking", "Linux", "Security Fundamentals"],
        "mode": "On-site",
        "stipend": "Not specified",
        "level": "Beginner / Intermediate",
        "url": "https://example.com"
    },
    {
        "title": "UI/UX Design Intern",
        "company": "PixelNest (Sample Listing)",
        "role": "UI/UX Designer",
        "skills": ["Figma", "Wireframing", "Prototyping", "Visual Design"],
        "mode": "Remote",
        "stipend": "Not specified",
        "level": "Beginner-friendly",
        "url": "https://example.com"
    }
]

RESOURCE_MAP = {
    "JavaScript": "Learn variables, functions, arrays, DOM events, and async basics.",
    "HTML & CSS": "Build a responsive page using semantic HTML, Flexbox, and Grid.",
    "React": "Practice components, props, state, and hooks by building a small interface.",
    "SQL": "Practice SELECT, filtering, joins, grouping, and aggregate queries.",
    "Backend APIs": "Learn HTTP methods and build a small REST API.",
    "Git & GitHub": "Practice commits, branches, pull requests, and README files.",
    "Excel": "Practice formulas, pivot tables, sorting, filtering, and charts.",
    "Python": "Practice functions, collections, file handling, and problem solving.",
    "Statistics": "Review averages, distributions, probability, and basic hypothesis testing.",
    "Data Visualization": "Build a clear dashboard with charts and written insights.",
    "Pandas": "Load a dataset, clean missing values, group data, and export results.",
    "Machine Learning": "Learn train/test splits, baseline models, and evaluation metrics.",
    "Data Structures": "Practice arrays, hash maps, stacks, queues, and complexity basics.",
    "Networking": "Review TCP/IP, DNS, ports, HTTP, and basic network troubleshooting.",
    "Linux": "Practice shell navigation, permissions, processes, and logs.",
    "Security Fundamentals": "Learn authentication, common vulnerabilities, and safe lab practices.",
    "Log Analysis": "Read sample logs and identify unusual events.",
    "Figma": "Create a small design system and a clickable prototype.",
    "Wireframing": "Sketch user flows and low-fidelity screen layouts.",
    "Prototyping": "Connect screens and test a short user journey.",
    "User Research": "Write interview questions and summarize user needs.",
    "Visual Design": "Practice hierarchy, spacing, typography, and accessibility."
}

@app.route("/")
def home():
    return render_template("index.html", roles=list(ROLE_SKILLS.keys()))

@app.route("/api/analyze", methods=["POST"])
def analyze():
    data = request.get_json(silent=True) or {}
    role = data.get("role", "")
    raw_skills = data.get("skills", [])
    if role not in ROLE_SKILLS:
        return jsonify({"error": "Please choose a valid job role."}), 400

    skills = {}
    if isinstance(raw_skills, list):
        for item in raw_skills:
            if isinstance(item, dict) and item.get("name") in ROLE_SKILLS[role]:
                try:
                    level = max(0, min(5, int(item.get("level", 0))))
                except (TypeError, ValueError):
                    level = 0
                skills[item["name"]] = level

    requirements = ROLE_SKILLS[role]
    matched, improve, missing = [], [], []
    weighted_score = 0
    total_weight = sum(requirements.values())

    for skill, required in requirements.items():
        current = skills.get(skill, 0)
        weighted_score += required * min(current / required, 1)
        item = {"name": skill, "required": required, "current": current}
        if current >= required:
            matched.append(item)
        elif current > 0:
            improve.append(item)
        else:
            missing.append(item)

    readiness = round((weighted_score / total_weight) * 100) if total_weight else 0
    roadmap = []
    for item in missing + improve:
        roadmap.append({
            "skill": item["name"],
            "current": item["current"],
            "required": item["required"],
            "suggestion": RESOURCE_MAP.get(item["name"], "Practice this skill and complete a small project.")
        })

    internships = []
    for internship in INTERNSHIPS:
        if internship["role"] != role:
            continue
        overlap = sum(1 for skill in internship["skills"] if skills.get(skill, 0) > 0)
        score = round((overlap / len(internship["skills"])) * 100) if internship["skills"] else 0
        internships.append({**internship, "match": score})

    internships.sort(key=lambda x: x["match"], reverse=True)
    return jsonify({
        "role": role,
        "readiness": readiness,
        "matched": matched,
        "improve": improve,
        "missing": missing,
        "roadmap": roadmap,
        "internships": internships
    })

if __name__ == "__main__":
    app.run(debug=True)
