SMART INTERNSHIP & SKILL MAPPING PLATFORM (DEMO)

Files:
  app.py                 Flask backend and sample role/internship data
  templates/index.html   Main website page
  static/style.css       Website styling
  static/app.js          Skill form, API request, results rendering
  requirements.txt       Python dependency

Requirements:
  Python 3.9+ recommended

Run:
  1. Open a terminal in this folder.
  2. (Optional) Create a virtual environment:
       python -m venv .venv
     Activate it:
       Windows: .venv\Scripts\activate
       macOS/Linux: source .venv/bin/activate
  3. Install dependency:
       pip install -r requirements.txt
  4. Start the app:
       python app.py
  5. Open http://127.0.0.1:5000 in your browser.

Notes:
  - This is a student-project prototype. It does not yet include login,
    persistent database storage, resume uploads, or live internship feeds.
  - Internship listings and example.com links are placeholders, not verified vacancies.
  - The readiness score is a simple rule-based learning indicator, not a hiring prediction.
  - For deployment, turn off Flask debug mode and add secure authentication,
    validation, a real database, and verified internship data.
